import {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
} from "./chunk-ESZRU4QG.js";
import "./chunk-YCT2PS64.js";
import "./chunk-TFGUMWD4.js";
import "./chunk-LQ7JEHJ2.js";
import "./chunk-LHRTKJE6.js";
import "./chunk-JN3CWD3G.js";
export {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
};
//# sourceMappingURL=@angular_fire_compat.js.map
