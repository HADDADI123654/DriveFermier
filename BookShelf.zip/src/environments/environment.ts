export const environment = {
  production: false,
  host: 'http://localhost:8080',
  firebaseConfig: {
    apiKey: "AIzaSyBYQf1D7wFq6Q9ik1Kizie-L3Rl7m674Ks",
    authDomain: "festive-ellipse-309416.firebaseapp.com",
    projectId: "festive-ellipse-309416",
    storageBucket: "festive-ellipse-309416.appspot.com",
    messagingSenderId: "225212699786",
    appId: "1:225212699786:web:306aa45e2ccfd757a68973",
    measurementId: "G-8SP3NNZH25"
  },
  previewUrl_A: "https://books.google.com.pk/books?id=",
  previewUrl_B: "&printsec=frontcover#v=onepage&q&f=false"
}
