import {Component, OnInit} from '@angular/core';
import {MatCard, MatCardContent, MatCardTitle} from "@angular/material/card";
import {MatGridList, MatGridTile} from "@angular/material/grid-list";
import {AbstractControl, FormBuilder, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {AuthService} from "../../service/Authservice";
import {Router} from "@angular/router";
import {AlertifyService} from "../../service/AlertifyService";

@Component({
  selector: 'app-register',
  standalone: true,
    imports: [
        MatCard,
        MatCardContent,
        MatCardTitle,
        MatGridList,
        MatGridTile,
        ReactiveFormsModule
    ],
  templateUrl: './register.component.html'
})
export class RegisterComponent implements OnInit{
  form!: FormGroup;
  emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  constructor(private formBuilder: FormBuilder, private authService: AuthService, private router: Router,
              private alertify: AlertifyService) {
  }
  ngOnInit() {
    this.form = this.formBuilder.group({
      regNo: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
      password: ['', [Validators.required, Validators.pattern(this.passwordPattern)]],
      confirmPassword: ['', [Validators.required]]
    });
  }
  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }
  onSubmit(){
    let matched = this.form.controls['confirmPassword'].value == this.form.controls['password'].value;
    if(!matched){
      this.alertify.error("Confirm Password mismatched");
      return;
    }else if(this.form.invalid){
      this.alertify.error("Form Invalid");
      return;
    }else {
      this.authService.register(this.form.controls['email'].value, this.form.controls['password'].value,
        this.form.controls['regNo'].value)
        .then((userCredential) => {
          debugger;
          if (userCredential && userCredential.user) {
            // Add custom user data to the user's profile
            return userCredential.user.updateProfile({
              displayName: this.form.controls['regNo'].value, // You can use displayName to store the role number
              // You can also store the role number in the Firebase user's custom claims
            }).then(() => {
              // Successfully updated user profile
              this.alertify.success('Registration successful:'+ userCredential.user?.email);
              this.router.navigate(['/']);
              return userCredential;
            }).catch((error) => {
              // Handle error while updating user profile
              this.alertify.error('Registration error:'+ error.message);
              throw error;
            });
          } else {
            this.alertify.error('User credential or user object is null');
            throw new Error('User credential or user object is null');
          }
        })
        .catch((error) => {
          this.alertify.error(error.message);
          throw error;
        })
      console.log(this.form.value)
    }
  }
  onPasswordConfirm(){
    this.form.controls['confirmPassword'].valueChanges.subscribe({
      next: (data: any)=>{
        if(this.form.controls['password'].value == data){
          console.log("Confirm Password mismatched")
        }else {
          this.form.markAllAsTouched(); // Mark all form controls as touched
          this.form.setErrors({ 'invalid': true }); // Set a custom error to indicate invalid form
        }
      }
    })
  }
  navigateToLogin() {
    this.router.navigate(['/']); // Replace 'register' with your actual route
  }
}
