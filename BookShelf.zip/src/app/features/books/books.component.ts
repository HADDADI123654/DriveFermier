import { Component, OnInit } from '@angular/core';
import { BookService } from '../../service/BookService';
import { Book } from '../../models/Book.model';
import { MatFormField } from '@angular/material/form-field';
import {
  MatCard,
  MatCardActions,
  MatCardContent,
  MatCardHeader,
  MatCardSubtitle,
  MatCardTitle,
} from '@angular/material/card';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { MatIcon } from '@angular/material/icon';
import { AlertifyService } from '../../service/AlertifyService';
import { Router } from '@angular/router';
import { AuthService } from '../../service/Authservice';
import { connectDatabaseEmulator } from '@angular/fire/database';
import { window } from 'rxjs';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-books',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    MatFormField,
    MatCard,
    MatCardHeader,
    MatCardContent,
    MatCardTitle,
    MatCardSubtitle,
    MatCardActions,
    MatIcon,
  ],
  templateUrl: './books.component.html',
})
export class BooksComponent implements OnInit {
  protected readonly environment = environment;
  form!: FormGroup;
  books: Book[] = [];
  categories: string[] = ['All'];
  loading: boolean = false;
  constructor(
    private bookService: BookService,
    private formBuilder: FormBuilder,
    private alertify: AlertifyService,
    private router: Router,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.form = this.formBuilder.group({
      category: [],
      keyword: [],
      test: [],
    });
    if (localStorage.getItem('userId') == null) {
      this.router.navigate(['/']);
    } else {
      this.searchBooks('Sports');
    }
  }
  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }
  searchBooks(query: string): void {
    this.loading = true;
    this.bookService.search(query).subscribe(
      (books: Book[]) => {
        this.loading = false;
        this.books = [];
        this.books = books; // Assign the fetched books to the array
      },
      (error) => {
        this.loading = false;
        this.alertify.error('Error fetching books: ' + error.message);
        // Handle error and provide user feedback
      }
    );
  }

  searchBooksWithCategory(category: string, keyword: string): void {
    this.bookService.searchBooksWithCategory(category, keyword).subscribe(
      (books: Book[]) => {
        this.books = books;
      },
      (error) => {
        this.alertify.error('Error fetching books: ' + error.message);
        // Handle error and provide user feedback
      }
    );
  }
  selectCategory(category: string): void {
    this.form.setControl('test', category);
  }
  logOut() {
    this.authService.signOut().then(
      () => {
        localStorage.removeItem('userId');
        this.alertify.success('User logout successfully.');
        this.router.navigate(['/']);
      },
      () => {
        this.alertify.error('Error on Logout');
      }
    );
  }
}
