import {Component, OnInit} from '@angular/core';
import {MatCard, MatCardContent, MatCardTitle} from "@angular/material/card";
import {AbstractControl, FormBuilder, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {MatFormField} from "@angular/material/form-field";
import {MatInputModule} from "@angular/material/input";
import {MatGridList, MatGridTile} from "@angular/material/grid-list";
import {MatButton} from "@angular/material/button";
import {AuthService} from "../../service/Authservice";
import {Router} from "@angular/router";
import {AlertifyService} from "../../service/AlertifyService";

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    MatCard,
    MatCardContent,
    MatCardTitle,
    ReactiveFormsModule,
    MatFormField,
    MatInputModule,
    MatGridList,
    MatGridTile,
    MatButton
  ],
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {
  form!: FormGroup;
  emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

  constructor(private formBuilder: FormBuilder, private authService: AuthService, private router: Router,
     private alertify: AlertifyService) {
  }
  ngOnInit() {
    this.form = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
      password: ['', [Validators.required, Validators.pattern(this.passwordPattern)]]
    });
  }
  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }

  onSubmit() {
    if (this.form.invalid) {
      this.alertify.error("Please fill all fields");
      return;
    } else {
      this.authService.login(this.form.controls['email'].value, this.form.controls['password'].value)
        .then((res: any) => {
          const user = res.user;
          localStorage.setItem("userId", user.uid);
          // alert('User signed in:'+ user.email);
          // alert('User ID:'+ user.uid);
          // alert('Display Name:'+ user.displayName);
          // alert('Email Verified:'+ user.emailVerified);
          // alert('Provider ID:'+ user.providerId);
          this.alertify.success('User signed in: '+ user.email);
          this.router.navigate(['/home']);
        }).catch((err: any) => {
        this.alertify.error(err.message);
      })
    }
  }

  resetPassword() {
    if (this.f['email'].errors) {
      this.alertify.error("Please enter email first")
      return;
    }
    this.authService.resetPassword(this.form.controls['email'].value).then(() => {
      this.alertify.success('Password reset email sent successfully');
    })
      .catch((error: any) => {
        this.alertify.error('Error sending password reset email:'+ error.message);
        // Handle error and provide user feedback
      });
  }

  navigateToRegister() {
    this.router.navigate(['/register']); // Replace 'register' with your actual route
  }
}
