import { Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { LoginComponent } from './features/login/login.component';
import { RegisterComponent } from './features/register/register.component';
import { BooksComponent } from './features/books/books.component';

export const routes: Routes = [
  {
    path: '',
    component: AppComponent,
    canActivate: [],
    children: [
      { path: '', component: LoginComponent },
      { path: 'register', component: RegisterComponent },
      { path: 'home', component: BooksComponent },
    ],
  },
];
