
import { Injectable } from '@angular/core';
import {AngularFireAuth} from "@angular/fire/compat/auth";
import firebase from 'firebase/compat/app';
import {environment} from "../../environments/environment";
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private angularFireAuth: AngularFireAuth) {
  }

  login(email: string, password: string) {
    return this.angularFireAuth.signInWithEmailAndPassword(email, password);
  }
  register(email: string, password: string, roleNumber: string) {
    return this.angularFireAuth.createUserWithEmailAndPassword(email, password);
  }
  resetPassword(email: string) {
    return this.angularFireAuth.sendPasswordResetEmail(email);
  }
  signOut(){
      return this.angularFireAuth.signOut();
  }
}
