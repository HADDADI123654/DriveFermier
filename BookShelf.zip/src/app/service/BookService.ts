import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {map, Observable} from "rxjs";
import {Book} from "../models/Book.model";
import {environment} from "../../environments/environment";

@Injectable(
  { providedIn: 'root' })
export class BookService {
  private API_PATH = 'https://www.googleapis.com/books/v1/volumes';

  constructor(private http: HttpClient) { }

  search(query: string): Observable<Book[]> {
    return this.http
      .get<{ items: Book[] }>(`${this.API_PATH}?q=${query} &maxResults=24&startIndex=0`)
      .pipe(map(books => books.items || []));
  }

  getById(volumeId: string): Observable<Book> {
    return this.http.get<Book>(`${this.API_PATH}/${volumeId}`);
  }

  searchBooksWithCategory(category: string, keyword: string): Observable<Book[]> {
    const query = `?q=${keyword}&subject=${category}`;
    const url = `${this.API_PATH}${query}`;

    return this.http.get<{ items: Book[] }>(url)
      .pipe(map(books => books.items || []));
  }

}
