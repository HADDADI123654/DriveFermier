import { Injectable } from '@angular/core';
import * as alertify from 'alertifyjs';
import { from, Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AlertifyService {

  constructor() { }

  // OTP Clear
  private OtpClear = new Subject<any>();
  OtpClearObservable$ = this.OtpClear.asObservable();

  ErrorConnectionMsg = "Services are temporarily unavailable.Try reloading the page";

  addUpdatePopup(content: any, title: string) {
    alertify.alert(content).setHeader(title).set('maximizable', true);
  }

  alert(title: string, message: string) {
    alertify.alert('<b>' + title + '</b>', message);
  }

  closeAlert() {
    alertify.alert().close();
  }

  // alertify.confirm('Confirm Title', 'Confirm Message', function(){ alertify.success('Ok') }
  //               , function(){ alertify.error('Cancel')});

  confirm(title: string, message: any, okCallback: () => any) {
    alertify.confirm('<b>' + title + '</b>', message, (e: any) => {
      if (e) {
        return okCallback();
      } else { }
    }, null).set('labels', { ok: "OK" });
  }

  confirmDailog(title: string, message: any, okCallback: () => any, cancelCallback: () => any) {
    alertify.confirm('<b>' + title + '</b>', message, (e: any) => {
      if (e) {
        return okCallback();
      } else { }
    }, (e: any) => {
      if (e) {
        return cancelCallback();
      }
    }).set('closable', false).set('labels', { ok: "OK" });
  }

  sessionExpire(title: string, message: any, okCallback: () => any, cancelCallback: () => any) {
    alertify.confirm('<b>' + title + '</b>', message, (e: any) => {
      if (e) {
        return okCallback();
      } else { }
    }, (e: any) => {
      if (e) {
        return cancelCallback();
      }
    }).set('closable', false).set( 'labels', { ok: "OK"});
  }

  GeneralConfirm(title: string, message: any, okButtonText: any, cancelButtonText: any, okCallback: () => any, cancelCallback: () => any) {
    alertify.confirm('<b>' + title + '</b>', message, (e: any) => {
      if (e) {
        return okCallback();
      } else { }
    }, (e: any) => {
      if (e) {
        return cancelCallback();
      }
    }).set('labels', { ok: okButtonText, cancel: cancelButtonText });
  }

  deleteConfirm(okCallback: () => any) {
    alertify.confirm('<b>Delete</b>', 'Are you sure want to delete.', (e: any) => {
      if (e) {
        return okCallback();
      } else { }
    }, null).set('labels', { ok: "OK" });
  }

  discardConfirm(okCallback: () => any) {
    alertify.confirm('<b>Discard</b>', 'Are you sure want to discard?', (e: any) => {
      if (e) {
        return okCallback();
      } else { }
    }, null).set('labels', { ok: "OK" });
  }

  success(message: string)
  {
    if (message == 'Profile name already exists.')
    {
      alertify.error(message);
    }

    else
    {
      alertify.success(message);
    }
  }

  error(message: string) {
    //IF you want to display message till user click then set it to 0
    //IF you want default then keep it blank default is 5 alertify.error(message);
    alertify.error(message,6);
  }

  warning(message: string) {
    alertify.warning(message);
  }

  message(message: string) {
    alertify.message(message);
  }

  prompt(title: string, message: string, okCallback: () => any) {
    alertify.prompt(null, message, (e: any) => {
      if (e) {
        return okCallback();
      } else { }
    }).setHeader(title).set('resizable', true);
  }
}
